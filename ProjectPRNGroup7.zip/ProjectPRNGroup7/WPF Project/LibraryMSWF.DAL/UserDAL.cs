﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace LibraryMSWF.DAL
{
    public class UserDAL
    {
        
        public DataSet GetAllUsersDAL()
        {
            SqlConnection conn = new SqlConnection("Server=(local); Database=LibraryMSWF; Integrated Security=true");
            SqlDataAdapter da = new SqlDataAdapter("GetAllUsers", conn);
            DataSet ds = new DataSet("Users");
            da.Fill(ds);
            return ds;
        }
    
        public string AddUserDAL(string userName, int userAdNo, string userEmail, string userPass)
        {
            SqlConnection conn = new SqlConnection("Server=(local); Database=LibraryMSWF; Integrated Security=true");
            SqlCommand cmd2 = new SqlCommand("Select count (*) from tblUsers where UserEmail=@email", conn);
            cmd2.Parameters.Add(new SqlParameter("@email", userEmail));
            conn.Open();
            int count = (int)cmd2.ExecuteScalar();
            conn.Close();
            if (count > 0)
            {
                return "User already exists, ";
            }
            else
            {
                SqlCommand cmd = new SqlCommand("AddUser @name, @adno, @email, @pass", conn);
                cmd.Parameters.Add(new SqlParameter("@name", userName));
                cmd.Parameters.Add(new SqlParameter("@adno", userAdNo));
                cmd.Parameters.Add(new SqlParameter("@email", userEmail));
                cmd.Parameters.Add(new SqlParameter("@pass", userPass));
                conn.Open();
                int rowAffected = cmd.ExecuteNonQuery();
                conn.Close();
                if (rowAffected > 0)
                {
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
        }
      
        public bool UpdateUserDAL(int userId, string userName, int userAdNo, string userEmail, string userPass)
        {
            SqlConnection conn = new SqlConnection("Server=(local); Database=LibraryMSWF; Integrated Security=true");
            SqlCommand cmd = new SqlCommand("UpdateUser @id, @name, @adno, @email, @pass", conn);
            cmd.Parameters.Add(new SqlParameter("@id", userId));
            cmd.Parameters.Add(new SqlParameter("@name", userName));
            cmd.Parameters.Add(new SqlParameter("@adno", userAdNo));
            cmd.Parameters.Add(new SqlParameter("@email", userEmail));
            cmd.Parameters.Add(new SqlParameter("@pass", userPass));
            conn.Open();
            int rowAffected = cmd.ExecuteNonQuery();
            conn.Close();
            if (rowAffected > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
     
        public bool DeleteUserDAL(int userId)
        {
            SqlConnection conn = new SqlConnection("Server=(local); Database=LibraryMSWF; Integrated Security=true");
            SqlCommand cmd = new SqlCommand("DeleteUser @id", conn);
            cmd.Parameters.Add(new SqlParameter("@id", userId));
            conn.Open();
            int rowAffected = cmd.ExecuteNonQuery();
            conn.Close();
            if (rowAffected > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
   
        public string TakeUserNameDAL(int userId)
        {
            SqlConnection conn = new SqlConnection("Server=(local); Database=LibraryMSWF; Integrated Security=true");
            SqlCommand cmd = new SqlCommand("TakeUserName @userId", conn);
            cmd.Parameters.Add(new SqlParameter("@userId", userId));
            conn.Open();
            string userName = (string)cmd.ExecuteScalar();
            conn.Close();
            return userName;
        }
    
        public int UserLoginDAL(string userEmail, string userPass)
        {
            try
            {
                SqlConnection conn = new SqlConnection("Server=(local); Database=LibraryMSWF; Integrated Security=true");
                SqlCommand cmd = new SqlCommand("UserLogin @email, @pass", conn);
                cmd.Parameters.Add(new SqlParameter("@email", userEmail));
                cmd.Parameters.Add(new SqlParameter("@pass", userPass));
                conn.Open();
                int userId = (int)cmd.ExecuteScalar();
                conn.Close();
                return userId;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
