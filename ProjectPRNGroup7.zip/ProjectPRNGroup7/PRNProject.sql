Create database LibraryMSWF
use LibraryMSWF

CREATE TABLE tblAdmins (
    AdminId INT PRIMARY KEY NOT NULL,
    AdminName NVARCHAR(50),
    AdminEmail NVARCHAR(50) NOT NULL,
    AdminPass NVARCHAR(50)
);

drop table tblBooks
CREATE TABLE tblBooks (
    BookId INT PRIMARY KEY identity NOT NULL,
    BookName NVARCHAR(50),
    BookAuthor NVARCHAR(50),
    BookISBN NVARCHAR(50),
    BookPrice MONEY,
    BookCopies INT
);

INSERT INTO tblBooks (BookName, BookAuthor, BookISBN, BookPrice, BookCopies)
VALUES 
('The Catcher in the Rye', 'J.D. Salinger', '9780316769488', 10.99, 5),
('Moby-Dick', 'Herman Melville', '9781503280786', 11.99, 2),
('War and Peace', 'Leo Tolstoy', '9781853260629', 14.99, 1),
('The Odyssey', 'Homer', '9780140268867', 12.99, 5),
('The Hobbit', 'J.R.R. Tolkien', '9780547928227', 13.99, 10);

drop table tblUsers
CREATE TABLE tblUsers (
    UserId INT PRIMARY KEY identity not null,
    UserName NVARCHAR(50),
    UserAdNo INT,
    UserEmail NVARCHAR(50),
    UserPass NVARCHAR(50)
);
drop table tblRecievedUsers
CREATE TABLE tblRecievedUsers (
    BookId INT,
    BookName NVARCHAR(50),
    DateRecieved DATE,
    UserId INT,
    UserName NVARCHAR(50),
    CONSTRAINT FK_Recieved_BookId FOREIGN KEY (BookId) REFERENCES tblBooks(BookId),
    CONSTRAINT FK_Recieved_UserId FOREIGN KEY (UserId) REFERENCES tblUsers(UserId)
);
drop table tblRequestedUsers
CREATE TABLE tblRequestedUsers (
    BookId INT,
    BookName NVARCHAR(50),
    DateRequested DATE,
    UserId INT,
    UserName NVARCHAR(50),
    CONSTRAINT FK_Requested_BookId FOREIGN KEY (BookId) REFERENCES tblBooks(BookId),
    CONSTRAINT FK_Requested_UserId FOREIGN KEY (UserId) REFERENCES tblUsers(UserId)
);
drop table tblReturnedUsers
CREATE TABLE tblReturnedUsers (
    BookId INT,
    BookName NVARCHAR(50),
    DateReturned DATE,
    UserId INT,
    UserName NVARCHAR(50),
    CONSTRAINT FK_Returned_BookId FOREIGN KEY (BookId) REFERENCES tblBooks(BookId),
    CONSTRAINT FK_Returned_UserId FOREIGN KEY (UserId) REFERENCES tblUsers(UserId)
);


set ansi_nulls on
set quoted_identifier on

create procedure [dbo].[AddBook] (@bookname varchar(50), @bookAuthor varchar(50), @bookISBN varchar(50), @bookPrice money, @bookCopies int) as begin
insert into tblBooks values (@bookName, @bookAuthor, @bookISBN, @bookPrice, @bookCopies);
end

create procedure [dbo].[AddRecieve] (@bookId int, @bookName varchar(50), @date date, @userId int, @userName varchar(50)) as 
begin
insert into tblRecievedUsers values (@bookId, @bookName, @date, @userId, @userName);
end 

create procedure [dbo].[AddRequest] (@bookId int, @bookName varchar(50), @date date, @userId int, @userName varchar(50)) as
begin
insert into tblRequestedUsers values (@bookId, @bookName, @date, @userId, @userName);
end

Create procedure [dbo].[AddReturn] (@bookId int, @bookName varchar(50), @date date, @userId int, @userName varchar(50)) as
begin
insert into tblReturnedUsers values (@bookId, @bookName, @date, @userId, @userName);
end 


CREATE procedure [dbo].[AddUser] (@userName varchar(50), @userAdNo int, @userEmail varchar(50), @userPass varchar(50)) as
begin
insert into tblUsers values (@userName, @userAdNo, @userEmail,@userPass);
end

create procedure [dbo].[AdminLogin] (@adminEmail varchar(50), @adminPass varchar(50)) as
begin select count(*) from tblAdmins where AdminEmail= @adminEmail and AdminPass= @adminPass;
end 

create procedure [dbo].[UserLogin] (@userEmail varchar(50), @userPass varchar(50)) as
begin select count(*) from tblUsers where UserEmail = @userEmail and UserPass = @userPass;
end

CREATE PROCEDURE [dbo].[UpdateUser]
    @id INT,
    @name nVARCHAR(50),
    @adNo int,
    @email nVARCHAR(50),
    @password nvarchar(50)
AS
BEGIN
    UPDATE tblUsers
    SET 
        UserName = @name,
        UserAdNo = @adNo,
        UserEmail = @email,
        UserPass = @password
    WHERE UserId = @id;
END

CREATE PROCEDURE [dbo].[TakeUserName] 
    @userId INT
AS
BEGIN
    SELECT UserName 
    FROM tblUsers 
    WHERE UserId = @userId;
END

CREATE PROCEDURE [dbo].[UpdateBook]
    @id INT,
    @name nVARCHAR(50),
    @author nVARCHAR(50),
    @isbn nVARCHAR(50),
    @price money,
    @copy INT
AS
BEGIN
    UPDATE tblBooks
    SET 
        BookName = @name,
        BookAuthor = @author,
        BookISBN = @isbn,
        BookPrice = @price,
        BookCopies = @copy
    WHERE BookId = @id;
END


create procedure [dbo].[DeleteBook] (@bookId int) as begin
delete tblBooks where BookId=@bookId;
end

create procedure [dbo].[DeleteRecieve] (@bookId int, @userId int) as
begin
delete top (1) from tblRecievedUsers where BookId=@bookId and UserId=@userId;
end

create procedure [dbo].[DeleteRequest] (@bookId int, @userId int) as begin
delete top (1) from tblRequestedUsers where BookId=@bookId and UserId=@userId;
end

create procedure [dbo].[DeleteReturn] (@bookId int, @userId int) as begin
delete top (1) from tblReturnedUsers where BookId=@bookId and UserId=@userId; 
end


create procedure [dbo].[DeleteUser] (@userId int) as
begin
delete from tblUsers where UserId=@userId
end

create procedure [dbo].[GetAllBooks] as
begin
select * from tblBooks;
end

create procedure [dbo].[GetAllUsers] as
begin select * from tblUsers;
end

create procedure [dbo].[GetAllRecieve] as
begin
select * from tblRecievedUsers;
end

create procedure [dbo].[GetAllRecieveUser] (@userId int) as
begin
select BookId, BookName, DateRecieved from tblRecievedUsers where UserId=@userId;
end

CREATE procedure [dbo].[GetAllRequest] as
begin
select * from tblRequestedUsers;
end

create procedure [dbo].[GetAllRequestUser] (@userId int) as
begin
select BookId, BookName, DateRequested from tblRequestedUsers where UserId=@userId;
end

create procedure [dbo].[GetAllReturn] as
begin
select * from tblReturnedUsers;
end

create procedure [dbo].[IncBookCopy] (@bookId int) as
begin
update tblBooks set BookCopies= BookCopies+1 where BookId=@bookId;
end
